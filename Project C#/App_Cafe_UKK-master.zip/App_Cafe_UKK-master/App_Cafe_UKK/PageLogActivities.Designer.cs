﻿
namespace App_Cafe_UKK
{
    partial class PageLogActivities
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAdmin = new System.Windows.Forms.Button();
            this.dgvLogActivities = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnManager = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnKasir = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnAll = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnSistem = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLogActivities)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(52, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(187, 38);
            this.label2.TabIndex = 2;
            this.label2.Text = "Log Activities";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnAdmin);
            this.panel1.Location = new System.Drawing.Point(930, 53);
            this.panel1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(185, 49);
            this.panel1.TabIndex = 4;
            // 
            // btnAdmin
            // 
            this.btnAdmin.BackColor = System.Drawing.Color.Sienna;
            this.btnAdmin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdmin.FlatAppearance.BorderSize = 0;
            this.btnAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdmin.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdmin.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAdmin.Location = new System.Drawing.Point(-11, -13);
            this.btnAdmin.Name = "btnAdmin";
            this.btnAdmin.Size = new System.Drawing.Size(208, 74);
            this.btnAdmin.TabIndex = 0;
            this.btnAdmin.Text = "Admin";
            this.btnAdmin.UseVisualStyleBackColor = false;
            this.btnAdmin.Click += new System.EventHandler(this.btnAdmin_Click);
            // 
            // dgvLogActivities
            // 
            this.dgvLogActivities.AllowUserToAddRows = false;
            this.dgvLogActivities.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLogActivities.Location = new System.Drawing.Point(59, 155);
            this.dgvLogActivities.Margin = new System.Windows.Forms.Padding(50);
            this.dgvLogActivities.Name = "dgvLogActivities";
            this.dgvLogActivities.ReadOnly = true;
            this.dgvLogActivities.RowHeadersWidth = 51;
            this.dgvLogActivities.RowTemplate.Height = 60;
            this.dgvLogActivities.Size = new System.Drawing.Size(1241, 539);
            this.dgvLogActivities.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnManager);
            this.panel2.Location = new System.Drawing.Point(745, 53);
            this.panel2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(185, 49);
            this.panel2.TabIndex = 3;
            // 
            // btnManager
            // 
            this.btnManager.BackColor = System.Drawing.Color.Sienna;
            this.btnManager.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManager.FlatAppearance.BorderSize = 0;
            this.btnManager.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManager.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManager.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnManager.Location = new System.Drawing.Point(-11, -13);
            this.btnManager.Name = "btnManager";
            this.btnManager.Size = new System.Drawing.Size(208, 74);
            this.btnManager.TabIndex = 0;
            this.btnManager.Text = "Manager";
            this.btnManager.UseVisualStyleBackColor = false;
            this.btnManager.Click += new System.EventHandler(this.btnManager_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnKasir);
            this.panel3.Location = new System.Drawing.Point(560, 53);
            this.panel3.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(185, 49);
            this.panel3.TabIndex = 2;
            // 
            // btnKasir
            // 
            this.btnKasir.BackColor = System.Drawing.Color.Sienna;
            this.btnKasir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKasir.FlatAppearance.BorderSize = 0;
            this.btnKasir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKasir.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKasir.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnKasir.Location = new System.Drawing.Point(-11, -13);
            this.btnKasir.Name = "btnKasir";
            this.btnKasir.Size = new System.Drawing.Size(208, 74);
            this.btnKasir.TabIndex = 0;
            this.btnKasir.Text = "Kasir";
            this.btnKasir.UseVisualStyleBackColor = false;
            this.btnKasir.Click += new System.EventHandler(this.btnKasir_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnAll);
            this.panel4.Location = new System.Drawing.Point(375, 53);
            this.panel4.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(185, 49);
            this.panel4.TabIndex = 1;
            // 
            // btnAll
            // 
            this.btnAll.BackColor = System.Drawing.Color.Chocolate;
            this.btnAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAll.FlatAppearance.BorderSize = 0;
            this.btnAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAll.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAll.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAll.Location = new System.Drawing.Point(-11, -13);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(208, 74);
            this.btnAll.TabIndex = 0;
            this.btnAll.Text = "All";
            this.btnAll.UseVisualStyleBackColor = false;
            this.btnAll.Click += new System.EventHandler(this.btnAll_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnSistem);
            this.panel5.Location = new System.Drawing.Point(1115, 53);
            this.panel5.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(185, 49);
            this.panel5.TabIndex = 5;
            // 
            // btnSistem
            // 
            this.btnSistem.BackColor = System.Drawing.Color.Sienna;
            this.btnSistem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSistem.FlatAppearance.BorderSize = 0;
            this.btnSistem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSistem.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSistem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSistem.Location = new System.Drawing.Point(-11, -13);
            this.btnSistem.Name = "btnSistem";
            this.btnSistem.Size = new System.Drawing.Size(208, 74);
            this.btnSistem.TabIndex = 0;
            this.btnSistem.Text = "Sistem";
            this.btnSistem.UseVisualStyleBackColor = false;
            this.btnSistem.Click += new System.EventHandler(this.btnSistem_Click);
            // 
            // PageLogActivities
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1359, 753);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.dgvLogActivities);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "PageLogActivities";
            this.Text = "PageLogActivities";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLogActivities)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnAdmin;
        private System.Windows.Forms.DataGridView dgvLogActivities;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnManager;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnKasir;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnAll;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnSistem;
    }
}