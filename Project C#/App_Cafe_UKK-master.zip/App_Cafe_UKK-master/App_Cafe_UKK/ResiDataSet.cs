﻿namespace App_Cafe_UKK
{


    partial class ResiDataSet
    {
        partial class dataTableResiDataTable
        {
        }
    }
}


namespace App_Cafe_UKK.ResiDataSetTableAdapters {
    
    
    public partial class dataTableCatatanTransaksiTableAdapter {
    }
}
