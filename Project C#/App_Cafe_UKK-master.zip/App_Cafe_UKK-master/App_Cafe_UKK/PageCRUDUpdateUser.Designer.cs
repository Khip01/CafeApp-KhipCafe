﻿
namespace App_Cafe_UKK
{
    partial class PageCRUDUpdateUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PageCRUDUpdateUser));
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblDangerSearch = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnSearch = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.dgvDataUser = new System.Windows.Forms.DataGridView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblDeskripsi = new System.Windows.Forms.Label();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblId = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.dtpTanggalLahir = new System.Windows.Forms.DateTimePicker();
            this.lblNoTelp = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pnlAdress = new System.Windows.Forms.Panel();
            this.lblAlamat = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblKelamin = new System.Windows.Forms.Label();
            this.lblPosisi = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pbProfile = new System.Windows.Forms.PictureBox();
            this.pnlSelectedUser = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.btnDeleteData = new System.Windows.Forms.Button();
            this.btnUpdateData = new System.Windows.Forms.Button();
            this.pnlUpdateMain = new System.Windows.Forms.Panel();
            this.pnlDeleteDanger = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.pnlUpdateChild = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btnSubmitUpdate = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.dangerUsername = new System.Windows.Forms.Label();
            this.lblAlphabetCounterUsername = new System.Windows.Forms.Label();
            this.pnlHintTelp = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.lblAlphabetCounterTelp = new System.Windows.Forms.Label();
            this.pnlHintId = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.pnlHintStatus = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.pbHintId = new System.Windows.Forms.PictureBox();
            this.pbHintStatus = new System.Windows.Forms.PictureBox();
            this.pbHintTelpNum = new System.Windows.Forms.PictureBox();
            this.lblAlphabetCounterAddr = new System.Windows.Forms.Label();
            this.lblAlphabetCounterDesc = new System.Windows.Forms.Label();
            this.dtpDateofBirth = new System.Windows.Forms.DateTimePicker();
            this.btnVisiblePassCreate = new System.Windows.Forms.Button();
            this.cbGender = new System.Windows.Forms.ComboBox();
            this.cbPosition = new System.Windows.Forms.ComboBox();
            this.dangerPosition = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtTelpNumber = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtIdKaryawan = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDataUser)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.pnlAdress.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbProfile)).BeginInit();
            this.pnlSelectedUser.SuspendLayout();
            this.pnlUpdateMain.SuspendLayout();
            this.pnlDeleteDanger.SuspendLayout();
            this.pnlUpdateChild.SuspendLayout();
            this.panel7.SuspendLayout();
            this.pnlHintTelp.SuspendLayout();
            this.pnlHintId.SuspendLayout();
            this.pnlHintStatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHintId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHintStatus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHintTelpNum)).BeginInit();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Khaki;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(66, 34);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(50, 10, 50, 10);
            this.label1.Size = new System.Drawing.Size(1238, 121);
            this.label1.TabIndex = 5;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkKhaki;
            this.panel1.Location = new System.Drawing.Point(59, 26);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1232, 121);
            this.panel1.TabIndex = 6;
            // 
            // lblDangerSearch
            // 
            this.lblDangerSearch.AutoSize = true;
            this.lblDangerSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDangerSearch.ForeColor = System.Drawing.Color.DarkRed;
            this.lblDangerSearch.Location = new System.Drawing.Point(56, 169);
            this.lblDangerSearch.Name = "lblDangerSearch";
            this.lblDangerSearch.Size = new System.Drawing.Size(238, 17);
            this.lblDangerSearch.TabIndex = 12;
            this.lblDangerSearch.Text = "*You\'re not looking for anything";
            this.lblDangerSearch.Visible = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel4.Controls.Add(this.btnSearch);
            this.panel4.Controls.Add(this.pictureBox2);
            this.panel4.Controls.Add(this.txtSearch);
            this.panel4.Location = new System.Drawing.Point(59, 189);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(528, 63);
            this.panel4.TabIndex = 11;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btnSearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSearch.FlatAppearance.BorderSize = 0;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.btnSearch.Location = new System.Drawing.Point(398, 0);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(130, 63);
            this.btnSearch.TabIndex = 1;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::App_Cafe_UKK.Properties.Resources.search32;
            this.pictureBox2.Location = new System.Drawing.Point(15, 13);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(37, 37);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // txtSearch
            // 
            this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSearch.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.Location = new System.Drawing.Point(58, 17);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(325, 27);
            this.txtSearch.TabIndex = 0;
            this.txtSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            // 
            // dgvDataUser
            // 
            this.dgvDataUser.AllowUserToAddRows = false;
            this.dgvDataUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDataUser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgvDataUser.Location = new System.Drawing.Point(59, 305);
            this.dgvDataUser.Name = "dgvDataUser";
            this.dgvDataUser.ReadOnly = true;
            this.dgvDataUser.RowHeadersWidth = 51;
            this.dgvDataUser.RowTemplate.Height = 24;
            this.dgvDataUser.Size = new System.Drawing.Size(829, 409);
            this.dgvDataUser.TabIndex = 8;
            this.dgvDataUser.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDataUser_CellContentDoubleClick);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Location = new System.Drawing.Point(59, 270);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(748, 34);
            this.panel3.TabIndex = 13;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::App_Cafe_UKK.Properties.Resources.information32;
            this.pictureBox1.Location = new System.Drawing.Point(3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(30, 30);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(41, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(606, 19);
            this.label2.TabIndex = 0;
            this.label2.Text = "Select items first before updating or deleting data. By double clicking on the ro" +
    "w to be selected";
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.flowLayoutPanel2);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.dtpTanggalLahir);
            this.panel2.Controls.Add(this.lblNoTelp);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.pnlAdress);
            this.panel2.Controls.Add(this.lblStatus);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.lblKelamin);
            this.panel2.Controls.Add(this.lblPosisi);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.pbProfile);
            this.panel2.Location = new System.Drawing.Point(10, 55);
            this.panel2.Margin = new System.Windows.Forms.Padding(10, 10, 10, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(393, 379);
            this.panel2.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel5.AutoScroll = true;
            this.panel5.Controls.Add(this.lblDeskripsi);
            this.panel5.Location = new System.Drawing.Point(9, 110);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(246, 88);
            this.panel5.TabIndex = 8;
            // 
            // lblDeskripsi
            // 
            this.lblDeskripsi.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblDeskripsi.AutoSize = true;
            this.lblDeskripsi.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblDeskripsi.Location = new System.Drawing.Point(22, 0);
            this.lblDeskripsi.Margin = new System.Windows.Forms.Padding(0);
            this.lblDeskripsi.MaximumSize = new System.Drawing.Size(200, 0);
            this.lblDeskripsi.Name = "lblDeskripsi";
            this.lblDeskripsi.Size = new System.Drawing.Size(41, 20);
            this.lblDeskripsi.TabIndex = 1;
            this.lblDeskripsi.Text = "Desc";
            this.lblDeskripsi.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.flowLayoutPanel2.AutoScroll = true;
            this.flowLayoutPanel2.Controls.Add(this.lblUsername);
            this.flowLayoutPanel2.Controls.Add(this.lblId);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(9, 19);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(258, 57);
            this.flowLayoutPanel2.TabIndex = 2;
            // 
            // lblUsername
            // 
            this.lblUsername.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblUsername.AutoSize = true;
            this.lblUsername.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.lblUsername.Location = new System.Drawing.Point(0, 10);
            this.lblUsername.Margin = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.lblUsername.MaximumSize = new System.Drawing.Size(160, 0);
            this.lblUsername.MinimumSize = new System.Drawing.Size(160, 0);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(160, 28);
            this.lblUsername.TabIndex = 1;
            this.lblUsername.Text = "Name";
            this.lblUsername.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblId.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lblId.Location = new System.Drawing.Point(160, 10);
            this.lblId.Margin = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(69, 28);
            this.lblId.TabIndex = 1;
            this.lblId.Text = "#K000";
            // 
            // panel6
            // 
            this.panel6.Location = new System.Drawing.Point(11, 600);
            this.panel6.Margin = new System.Windows.Forms.Padding(0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(344, 23);
            this.panel6.TabIndex = 7;
            // 
            // dtpTanggalLahir
            // 
            this.dtpTanggalLahir.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpTanggalLahir.Location = new System.Drawing.Point(17, 567);
            this.dtpTanggalLahir.Name = "dtpTanggalLahir";
            this.dtpTanggalLahir.Size = new System.Drawing.Size(249, 27);
            this.dtpTanggalLahir.TabIndex = 6;
            // 
            // lblNoTelp
            // 
            this.lblNoTelp.AutoSize = true;
            this.lblNoTelp.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoTelp.Location = new System.Drawing.Point(175, 485);
            this.lblNoTelp.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.lblNoTelp.Name = "lblNoTelp";
            this.lblNoTelp.Size = new System.Drawing.Size(15, 20);
            this.lblNoTelp.TabIndex = 4;
            this.lblNoTelp.Text = "-";
            this.lblNoTelp.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(16, 530);
            this.label8.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(127, 25);
            this.label8.TabIndex = 5;
            this.label8.Text = "Date of Birth :";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(16, 480);
            this.label6.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(158, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "Telephone Num. :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // pnlAdress
            // 
            this.pnlAdress.AutoScroll = true;
            this.pnlAdress.Controls.Add(this.lblAlamat);
            this.pnlAdress.Location = new System.Drawing.Point(24, 365);
            this.pnlAdress.Name = "pnlAdress";
            this.pnlAdress.Size = new System.Drawing.Size(275, 100);
            this.pnlAdress.TabIndex = 3;
            // 
            // lblAlamat
            // 
            this.lblAlamat.AutoSize = true;
            this.lblAlamat.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlamat.Location = new System.Drawing.Point(3, 0);
            this.lblAlamat.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.lblAlamat.MaximumSize = new System.Drawing.Size(250, 0);
            this.lblAlamat.Name = "lblAlamat";
            this.lblAlamat.Size = new System.Drawing.Size(15, 20);
            this.lblAlamat.TabIndex = 1;
            this.lblAlamat.Text = "-";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.ForeColor = System.Drawing.Color.OliveDrab;
            this.lblStatus.Location = new System.Drawing.Point(108, 291);
            this.lblStatus.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(65, 20);
            this.lblStatus.TabIndex = 1;
            this.lblStatus.Text = "ONLINE";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(19, 327);
            this.label11.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(88, 25);
            this.label11.TabIndex = 1;
            this.label11.Text = "Address :";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(19, 286);
            this.label12.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 25);
            this.label12.TabIndex = 1;
            this.label12.Text = "Status    :";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblKelamin
            // 
            this.lblKelamin.AutoSize = true;
            this.lblKelamin.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKelamin.Location = new System.Drawing.Point(108, 212);
            this.lblKelamin.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.lblKelamin.Name = "lblKelamin";
            this.lblKelamin.Size = new System.Drawing.Size(15, 20);
            this.lblKelamin.TabIndex = 1;
            this.lblKelamin.Text = "-";
            this.lblKelamin.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblPosisi
            // 
            this.lblPosisi.AutoSize = true;
            this.lblPosisi.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPosisi.Location = new System.Drawing.Point(108, 248);
            this.lblPosisi.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.lblPosisi.Name = "lblPosisi";
            this.lblPosisi.Size = new System.Drawing.Size(15, 20);
            this.lblPosisi.TabIndex = 1;
            this.lblPosisi.Text = "-";
            this.lblPosisi.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(19, 207);
            this.label10.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 25);
            this.label10.TabIndex = 1;
            this.label10.Text = "Gender  :";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(19, 243);
            this.label4.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 25);
            this.label4.TabIndex = 1;
            this.label4.Text = "Position :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // pbProfile
            // 
            this.pbProfile.Location = new System.Drawing.Point(282, 13);
            this.pbProfile.Margin = new System.Windows.Forms.Padding(10);
            this.pbProfile.Name = "pbProfile";
            this.pbProfile.Size = new System.Drawing.Size(72, 72);
            this.pbProfile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbProfile.TabIndex = 0;
            this.pbProfile.TabStop = false;
            // 
            // pnlSelectedUser
            // 
            this.pnlSelectedUser.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pnlSelectedUser.Controls.Add(this.label3);
            this.pnlSelectedUser.Controls.Add(this.panel2);
            this.pnlSelectedUser.Controls.Add(this.btnDeleteData);
            this.pnlSelectedUser.Controls.Add(this.btnUpdateData);
            this.pnlSelectedUser.Enabled = false;
            this.pnlSelectedUser.Location = new System.Drawing.Point(904, 189);
            this.pnlSelectedUser.Name = "pnlSelectedUser";
            this.pnlSelectedUser.Size = new System.Drawing.Size(413, 525);
            this.pnlSelectedUser.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 28);
            this.label3.TabIndex = 1;
            this.label3.Text = "Selected User";
            // 
            // btnDeleteData
            // 
            this.btnDeleteData.BackColor = System.Drawing.Color.Firebrick;
            this.btnDeleteData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDeleteData.FlatAppearance.BorderSize = 0;
            this.btnDeleteData.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteData.ForeColor = System.Drawing.SystemColors.Control;
            this.btnDeleteData.Image = global::App_Cafe_UKK.Properties.Resources.remove24;
            this.btnDeleteData.Location = new System.Drawing.Point(211, 445);
            this.btnDeleteData.Margin = new System.Windows.Forms.Padding(10);
            this.btnDeleteData.Name = "btnDeleteData";
            this.btnDeleteData.Size = new System.Drawing.Size(192, 71);
            this.btnDeleteData.TabIndex = 9;
            this.btnDeleteData.Text = " Delete data";
            this.btnDeleteData.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDeleteData.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDeleteData.UseVisualStyleBackColor = false;
            this.btnDeleteData.Click += new System.EventHandler(this.btnDeleteData_Click);
            // 
            // btnUpdateData
            // 
            this.btnUpdateData.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnUpdateData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdateData.FlatAppearance.BorderSize = 0;
            this.btnUpdateData.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateData.ForeColor = System.Drawing.SystemColors.Control;
            this.btnUpdateData.Image = global::App_Cafe_UKK.Properties.Resources.Edit24;
            this.btnUpdateData.Location = new System.Drawing.Point(10, 444);
            this.btnUpdateData.Margin = new System.Windows.Forms.Padding(10);
            this.btnUpdateData.Name = "btnUpdateData";
            this.btnUpdateData.Size = new System.Drawing.Size(192, 71);
            this.btnUpdateData.TabIndex = 9;
            this.btnUpdateData.Text = " Update Data";
            this.btnUpdateData.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUpdateData.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnUpdateData.UseVisualStyleBackColor = false;
            this.btnUpdateData.Click += new System.EventHandler(this.btnUpdateData_Click);
            // 
            // pnlUpdateMain
            // 
            this.pnlUpdateMain.Controls.Add(this.pnlDeleteDanger);
            this.pnlUpdateMain.Controls.Add(this.label1);
            this.pnlUpdateMain.Controls.Add(this.pnlSelectedUser);
            this.pnlUpdateMain.Controls.Add(this.panel1);
            this.pnlUpdateMain.Controls.Add(this.panel3);
            this.pnlUpdateMain.Controls.Add(this.lblDangerSearch);
            this.pnlUpdateMain.Controls.Add(this.dgvDataUser);
            this.pnlUpdateMain.Controls.Add(this.panel4);
            this.pnlUpdateMain.Controls.Add(this.btnRefresh);
            this.pnlUpdateMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlUpdateMain.Location = new System.Drawing.Point(0, 0);
            this.pnlUpdateMain.Name = "pnlUpdateMain";
            this.pnlUpdateMain.Size = new System.Drawing.Size(1380, 772);
            this.pnlUpdateMain.TabIndex = 15;
            // 
            // pnlDeleteDanger
            // 
            this.pnlDeleteDanger.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pnlDeleteDanger.Controls.Add(this.label24);
            this.pnlDeleteDanger.Location = new System.Drawing.Point(1110, 696);
            this.pnlDeleteDanger.Name = "pnlDeleteDanger";
            this.pnlDeleteDanger.Size = new System.Drawing.Size(202, 54);
            this.pnlDeleteDanger.TabIndex = 15;
            this.pnlDeleteDanger.Visible = false;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(12, 7);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(178, 40);
            this.label24.TabIndex = 0;
            this.label24.Text = "Users with ONLINE status \r\ncannot be deleted.";
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnRefresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRefresh.FlatAppearance.BorderSize = 0;
            this.btnRefresh.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.ForeColor = System.Drawing.SystemColors.Control;
            this.btnRefresh.Image = global::App_Cafe_UKK.Properties.Resources.refresh24;
            this.btnRefresh.Location = new System.Drawing.Point(628, 185);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(260, 71);
            this.btnRefresh.TabIndex = 9;
            this.btnRefresh.Text = " Refresh Data";
            this.btnRefresh.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRefresh.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // pnlUpdateChild
            // 
            this.pnlUpdateChild.AutoScroll = true;
            this.pnlUpdateChild.BackColor = System.Drawing.SystemColors.Control;
            this.pnlUpdateChild.Controls.Add(this.btnCancel);
            this.pnlUpdateChild.Controls.Add(this.panel9);
            this.pnlUpdateChild.Controls.Add(this.btnSubmitUpdate);
            this.pnlUpdateChild.Controls.Add(this.panel7);
            this.pnlUpdateChild.Controls.Add(this.panel8);
            this.pnlUpdateChild.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlUpdateChild.ForeColor = System.Drawing.SystemColors.ControlText;
            this.pnlUpdateChild.Location = new System.Drawing.Point(0, 0);
            this.pnlUpdateChild.Name = "pnlUpdateChild";
            this.pnlUpdateChild.Size = new System.Drawing.Size(1380, 772);
            this.pnlUpdateChild.TabIndex = 15;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.LightCoral;
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.ForeColor = System.Drawing.SystemColors.Control;
            this.btnCancel.Image = global::App_Cafe_UKK.Properties.Resources.Close32;
            this.btnCancel.Location = new System.Drawing.Point(1112, 785);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(0);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(176, 58);
            this.btnCancel.TabIndex = 15;
            this.btnCancel.Text = "Cancel Edit";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // panel9
            // 
            this.panel9.Location = new System.Drawing.Point(74, 899);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1217, 29);
            this.panel9.TabIndex = 14;
            // 
            // btnSubmitUpdate
            // 
            this.btnSubmitUpdate.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnSubmitUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSubmitUpdate.FlatAppearance.BorderSize = 0;
            this.btnSubmitUpdate.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitUpdate.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSubmitUpdate.Image = global::App_Cafe_UKK.Properties.Resources.Edit24;
            this.btnSubmitUpdate.Location = new System.Drawing.Point(512, 823);
            this.btnSubmitUpdate.Margin = new System.Windows.Forms.Padding(10);
            this.btnSubmitUpdate.Name = "btnSubmitUpdate";
            this.btnSubmitUpdate.Size = new System.Drawing.Size(301, 71);
            this.btnSubmitUpdate.TabIndex = 13;
            this.btnSubmitUpdate.Text = " Submit Update Data";
            this.btnSubmitUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSubmitUpdate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSubmitUpdate.UseVisualStyleBackColor = false;
            this.btnSubmitUpdate.Click += new System.EventHandler(this.btnSubmitUpdate_Click);
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.dangerUsername);
            this.panel7.Controls.Add(this.lblAlphabetCounterUsername);
            this.panel7.Controls.Add(this.pnlHintTelp);
            this.panel7.Controls.Add(this.lblAlphabetCounterTelp);
            this.panel7.Controls.Add(this.pnlHintId);
            this.panel7.Controls.Add(this.pnlHintStatus);
            this.panel7.Controls.Add(this.pbHintId);
            this.panel7.Controls.Add(this.pbHintStatus);
            this.panel7.Controls.Add(this.pbHintTelpNum);
            this.panel7.Controls.Add(this.lblAlphabetCounterAddr);
            this.panel7.Controls.Add(this.lblAlphabetCounterDesc);
            this.panel7.Controls.Add(this.dtpDateofBirth);
            this.panel7.Controls.Add(this.btnVisiblePassCreate);
            this.panel7.Controls.Add(this.cbGender);
            this.panel7.Controls.Add(this.cbPosition);
            this.panel7.Controls.Add(this.dangerPosition);
            this.panel7.Controls.Add(this.label5);
            this.panel7.Controls.Add(this.label7);
            this.panel7.Controls.Add(this.label9);
            this.panel7.Controls.Add(this.label14);
            this.panel7.Controls.Add(this.txtDescription);
            this.panel7.Controls.Add(this.txtAddress);
            this.panel7.Controls.Add(this.label16);
            this.panel7.Controls.Add(this.label18);
            this.panel7.Controls.Add(this.txtStatus);
            this.panel7.Controls.Add(this.label19);
            this.panel7.Controls.Add(this.label20);
            this.panel7.Controls.Add(this.label21);
            this.panel7.Controls.Add(this.label22);
            this.panel7.Controls.Add(this.txtTelpNumber);
            this.panel7.Controls.Add(this.txtPassword);
            this.panel7.Controls.Add(this.label23);
            this.panel7.Controls.Add(this.txtUsername);
            this.panel7.Controls.Add(this.txtIdKaryawan);
            this.panel7.Location = new System.Drawing.Point(74, 81);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1214, 701);
            this.panel7.TabIndex = 10;
            // 
            // dangerUsername
            // 
            this.dangerUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dangerUsername.ForeColor = System.Drawing.Color.Red;
            this.dangerUsername.Image = global::App_Cafe_UKK.Properties.Resources.important24;
            this.dangerUsername.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.dangerUsername.Location = new System.Drawing.Point(638, 85);
            this.dangerUsername.MinimumSize = new System.Drawing.Size(194, 29);
            this.dangerUsername.Name = "dangerUsername";
            this.dangerUsername.Size = new System.Drawing.Size(194, 29);
            this.dangerUsername.TabIndex = 4;
            this.dangerUsername.Text = "This field is required";
            this.dangerUsername.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.dangerUsername.Visible = false;
            // 
            // lblAlphabetCounterUsername
            // 
            this.lblAlphabetCounterUsername.AutoSize = true;
            this.lblAlphabetCounterUsername.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlphabetCounterUsername.Location = new System.Drawing.Point(625, 84);
            this.lblAlphabetCounterUsername.Name = "lblAlphabetCounterUsername";
            this.lblAlphabetCounterUsername.Size = new System.Drawing.Size(90, 19);
            this.lblAlphabetCounterUsername.TabIndex = 11;
            this.lblAlphabetCounterUsername.Text = "40 remaining";
            // 
            // pnlHintTelp
            // 
            this.pnlHintTelp.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.pnlHintTelp.Controls.Add(this.label13);
            this.pnlHintTelp.Location = new System.Drawing.Point(596, 359);
            this.pnlHintTelp.Name = "pnlHintTelp";
            this.pnlHintTelp.Size = new System.Drawing.Size(492, 49);
            this.pnlHintTelp.TabIndex = 10;
            this.pnlHintTelp.Visible = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(6, 6);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(401, 38);
            this.label13.TabIndex = 0;
            this.label13.Text = "The phone number currently only supports Indonesian numbers\r\nEx: 855XXXXXXXX (Now" +
    " support 11/12/13 digit number)";
            // 
            // lblAlphabetCounterTelp
            // 
            this.lblAlphabetCounterTelp.AutoSize = true;
            this.lblAlphabetCounterTelp.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlphabetCounterTelp.Location = new System.Drawing.Point(592, 371);
            this.lblAlphabetCounterTelp.Name = "lblAlphabetCounterTelp";
            this.lblAlphabetCounterTelp.Size = new System.Drawing.Size(206, 19);
            this.lblAlphabetCounterTelp.TabIndex = 8;
            this.lblAlphabetCounterTelp.Text = "12 remaining (INVALID number)";
            // 
            // pnlHintId
            // 
            this.pnlHintId.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.pnlHintId.Controls.Add(this.label17);
            this.pnlHintId.Location = new System.Drawing.Point(578, 24);
            this.pnlHintId.Name = "pnlHintId";
            this.pnlHintId.Size = new System.Drawing.Size(571, 36);
            this.pnlHintId.TabIndex = 10;
            this.pnlHintId.Visible = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 8);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(493, 19);
            this.label17.TabIndex = 0;
            this.label17.Text = "The ID has been generated automatically so the Admin doesn\'t need to input it";
            // 
            // pnlHintStatus
            // 
            this.pnlHintStatus.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.pnlHintStatus.Controls.Add(this.label15);
            this.pnlHintStatus.Location = new System.Drawing.Point(552, 246);
            this.pnlHintStatus.Name = "pnlHintStatus";
            this.pnlHintStatus.Size = new System.Drawing.Size(571, 49);
            this.pnlHintStatus.TabIndex = 10;
            this.pnlHintStatus.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(6, 6);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(541, 38);
            this.label15.TabIndex = 0;
            this.label15.Text = "The ONLINE or OFFLINE status cannot be changed because it will change automatical" +
    "ly\r\naccording to the user\'s current status";
            // 
            // pbHintId
            // 
            this.pbHintId.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbHintId.Image = global::App_Cafe_UKK.Properties.Resources.askQuestion24;
            this.pbHintId.Location = new System.Drawing.Point(545, 29);
            this.pbHintId.Name = "pbHintId";
            this.pbHintId.Size = new System.Drawing.Size(28, 29);
            this.pbHintId.TabIndex = 9;
            this.pbHintId.TabStop = false;
            this.pbHintId.MouseEnter += new System.EventHandler(this.pbHintId_MouseEnter);
            this.pbHintId.MouseLeave += new System.EventHandler(this.pbHintId_MouseLeave);
            // 
            // pbHintStatus
            // 
            this.pbHintStatus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbHintStatus.Image = global::App_Cafe_UKK.Properties.Resources.askQuestion24;
            this.pbHintStatus.Location = new System.Drawing.Point(512, 257);
            this.pbHintStatus.Name = "pbHintStatus";
            this.pbHintStatus.Size = new System.Drawing.Size(28, 29);
            this.pbHintStatus.TabIndex = 9;
            this.pbHintStatus.TabStop = false;
            this.pbHintStatus.MouseEnter += new System.EventHandler(this.pbHintStatus_MouseEnter);
            this.pbHintStatus.MouseLeave += new System.EventHandler(this.pbHintStatus_MouseLeave);
            // 
            // pbHintTelpNum
            // 
            this.pbHintTelpNum.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbHintTelpNum.Image = global::App_Cafe_UKK.Properties.Resources.askQuestion24;
            this.pbHintTelpNum.Location = new System.Drawing.Point(557, 371);
            this.pbHintTelpNum.Name = "pbHintTelpNum";
            this.pbHintTelpNum.Size = new System.Drawing.Size(28, 29);
            this.pbHintTelpNum.TabIndex = 9;
            this.pbHintTelpNum.TabStop = false;
            this.pbHintTelpNum.MouseEnter += new System.EventHandler(this.pbHintTelpNum_MouseEnter);
            this.pbHintTelpNum.MouseLeave += new System.EventHandler(this.pbHintTelpNum_MouseLeave);
            // 
            // lblAlphabetCounterAddr
            // 
            this.lblAlphabetCounterAddr.AutoSize = true;
            this.lblAlphabetCounterAddr.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlphabetCounterAddr.Location = new System.Drawing.Point(838, 313);
            this.lblAlphabetCounterAddr.Name = "lblAlphabetCounterAddr";
            this.lblAlphabetCounterAddr.Size = new System.Drawing.Size(98, 19);
            this.lblAlphabetCounterAddr.TabIndex = 8;
            this.lblAlphabetCounterAddr.Text = "250 remaining";
            // 
            // lblAlphabetCounterDesc
            // 
            this.lblAlphabetCounterDesc.AutoSize = true;
            this.lblAlphabetCounterDesc.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlphabetCounterDesc.Location = new System.Drawing.Point(838, 540);
            this.lblAlphabetCounterDesc.Name = "lblAlphabetCounterDesc";
            this.lblAlphabetCounterDesc.Size = new System.Drawing.Size(98, 19);
            this.lblAlphabetCounterDesc.TabIndex = 8;
            this.lblAlphabetCounterDesc.Text = "250 remaining";
            // 
            // dtpDateofBirth
            // 
            this.dtpDateofBirth.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDateofBirth.Location = new System.Drawing.Point(336, 420);
            this.dtpDateofBirth.Margin = new System.Windows.Forms.Padding(3, 20, 3, 3);
            this.dtpDateofBirth.Name = "dtpDateofBirth";
            this.dtpDateofBirth.Size = new System.Drawing.Size(330, 34);
            this.dtpDateofBirth.TabIndex = 8;
            // 
            // btnVisiblePassCreate
            // 
            this.btnVisiblePassCreate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnVisiblePassCreate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVisiblePassCreate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVisiblePassCreate.Image = global::App_Cafe_UKK.Properties.Resources.EyeHide24;
            this.btnVisiblePassCreate.Location = new System.Drawing.Point(582, 137);
            this.btnVisiblePassCreate.Name = "btnVisiblePassCreate";
            this.btnVisiblePassCreate.Size = new System.Drawing.Size(39, 36);
            this.btnVisiblePassCreate.TabIndex = 6;
            this.btnVisiblePassCreate.UseVisualStyleBackColor = true;
            this.btnVisiblePassCreate.Click += new System.EventHandler(this.btnVisiblePassCreate_Click);
            // 
            // cbGender
            // 
            this.cbGender.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cbGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbGender.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbGender.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbGender.FormattingEnabled = true;
            this.cbGender.Location = new System.Drawing.Point(336, 477);
            this.cbGender.Margin = new System.Windows.Forms.Padding(3, 20, 3, 3);
            this.cbGender.Name = "cbGender";
            this.cbGender.Size = new System.Drawing.Size(283, 36);
            this.cbGender.TabIndex = 9;
            // 
            // cbPosition
            // 
            this.cbPosition.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cbPosition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPosition.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbPosition.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPosition.FormattingEnabled = true;
            this.cbPosition.Location = new System.Drawing.Point(336, 195);
            this.cbPosition.Margin = new System.Windows.Forms.Padding(3, 20, 3, 3);
            this.cbPosition.Name = "cbPosition";
            this.cbPosition.Size = new System.Drawing.Size(283, 36);
            this.cbPosition.TabIndex = 4;
            this.cbPosition.TextChanged += new System.EventHandler(this.cbPosition_TextChanged);
            // 
            // dangerPosition
            // 
            this.dangerPosition.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dangerPosition.ForeColor = System.Drawing.Color.Red;
            this.dangerPosition.Image = global::App_Cafe_UKK.Properties.Resources.important24;
            this.dangerPosition.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.dangerPosition.Location = new System.Drawing.Point(638, 201);
            this.dangerPosition.Name = "dangerPosition";
            this.dangerPosition.Size = new System.Drawing.Size(194, 29);
            this.dangerPosition.TabIndex = 4;
            this.dangerPosition.Text = "This field is required";
            this.dangerPosition.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.dangerPosition.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(14, 540);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(304, 28);
            this.label5.TabIndex = 2;
            this.label5.Text = "Description (Describe yourself) :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(14, 312);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 28);
            this.label7.TabIndex = 2;
            this.label7.Text = "Address :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(14, 483);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 28);
            this.label9.TabIndex = 2;
            this.label9.Text = "Gender :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label14.Location = new System.Drawing.Point(14, 255);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(78, 28);
            this.label14.TabIndex = 2;
            this.label14.Text = "Status :";
            // 
            // txtDescription
            // 
            this.txtDescription.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescription.Location = new System.Drawing.Point(336, 537);
            this.txtDescription.Margin = new System.Windows.Forms.Padding(3, 20, 3, 3);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(496, 130);
            this.txtDescription.TabIndex = 10;
            this.txtDescription.TextChanged += new System.EventHandler(this.txtDescription_TextChanged);
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(336, 309);
            this.txtAddress.Margin = new System.Windows.Forms.Padding(3, 20, 3, 3);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(496, 34);
            this.txtAddress.TabIndex = 6;
            this.txtAddress.TextChanged += new System.EventHandler(this.txtAddress_TextChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label16.Location = new System.Drawing.Point(14, 426);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(140, 28);
            this.label16.TabIndex = 2;
            this.label16.Text = "Date of Birth :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label18.Location = new System.Drawing.Point(14, 198);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(96, 28);
            this.label18.TabIndex = 2;
            this.label18.Text = "Position :";
            // 
            // txtStatus
            // 
            this.txtStatus.Enabled = false;
            this.txtStatus.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStatus.Location = new System.Drawing.Point(336, 252);
            this.txtStatus.Margin = new System.Windows.Forms.Padding(3, 20, 3, 3);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(170, 34);
            this.txtStatus.TabIndex = 5;
            this.txtStatus.Text = "OFFLINE";
            this.txtStatus.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(331, 369);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(48, 28);
            this.label19.TabIndex = 2;
            this.label19.Text = "+62";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label20.Location = new System.Drawing.Point(14, 369);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(199, 28);
            this.label20.TabIndex = 2;
            this.label20.Text = "Telephone Number :";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label21.Location = new System.Drawing.Point(14, 141);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(155, 28);
            this.label21.TabIndex = 2;
            this.label21.Text = "New Password :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label22.Location = new System.Drawing.Point(14, 84);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(115, 28);
            this.label22.TabIndex = 2;
            this.label22.Text = "Username :";
            // 
            // txtTelpNumber
            // 
            this.txtTelpNumber.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelpNumber.Location = new System.Drawing.Point(385, 366);
            this.txtTelpNumber.Margin = new System.Windows.Forms.Padding(3, 20, 3, 3);
            this.txtTelpNumber.Name = "txtTelpNumber";
            this.txtTelpNumber.Size = new System.Drawing.Size(165, 34);
            this.txtTelpNumber.TabIndex = 7;
            this.txtTelpNumber.TextChanged += new System.EventHandler(this.txtTelpNumber_TextChanged);
            // 
            // txtPassword
            // 
            this.txtPassword.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(336, 138);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(3, 20, 3, 3);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(238, 34);
            this.txtPassword.TabIndex = 3;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label23.Location = new System.Drawing.Point(14, 27);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(271, 28);
            this.label23.TabIndex = 2;
            this.label23.Text = "ID Karyawan (Employee ID) :";
            // 
            // txtUsername
            // 
            this.txtUsername.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsername.Location = new System.Drawing.Point(336, 81);
            this.txtUsername.Margin = new System.Windows.Forms.Padding(3, 20, 3, 3);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(283, 34);
            this.txtUsername.TabIndex = 2;
            this.txtUsername.TextChanged += new System.EventHandler(this.txtUsername_TextChanged);
            // 
            // txtIdKaryawan
            // 
            this.txtIdKaryawan.Enabled = false;
            this.txtIdKaryawan.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIdKaryawan.Location = new System.Drawing.Point(336, 24);
            this.txtIdKaryawan.Margin = new System.Windows.Forms.Padding(3, 20, 3, 3);
            this.txtIdKaryawan.Name = "txtIdKaryawan";
            this.txtIdKaryawan.Size = new System.Drawing.Size(203, 34);
            this.txtIdKaryawan.TabIndex = 1;
            this.txtIdKaryawan.Text = "Auto Generated";
            this.txtIdKaryawan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label26);
            this.panel8.Location = new System.Drawing.Point(74, 14);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1214, 61);
            this.panel8.TabIndex = 11;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Segoe UI Semibold", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(3, 12);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(185, 38);
            this.label26.TabIndex = 1;
            this.label26.Text = "UPDATE User";
            // 
            // PageCRUDUpdateUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1380, 772);
            this.Controls.Add(this.pnlUpdateMain);
            this.Controls.Add(this.pnlUpdateChild);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "PageCRUDUpdateUser";
            this.Text = "PageCRUDUpdateUser";
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDataUser)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel2.PerformLayout();
            this.pnlAdress.ResumeLayout(false);
            this.pnlAdress.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbProfile)).EndInit();
            this.pnlSelectedUser.ResumeLayout(false);
            this.pnlSelectedUser.PerformLayout();
            this.pnlUpdateMain.ResumeLayout(false);
            this.pnlUpdateMain.PerformLayout();
            this.pnlDeleteDanger.ResumeLayout(false);
            this.pnlDeleteDanger.PerformLayout();
            this.pnlUpdateChild.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.pnlHintTelp.ResumeLayout(false);
            this.pnlHintTelp.PerformLayout();
            this.pnlHintId.ResumeLayout(false);
            this.pnlHintId.PerformLayout();
            this.pnlHintStatus.ResumeLayout(false);
            this.pnlHintStatus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHintId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHintStatus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHintTelpNum)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblDangerSearch;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.DataGridView dgvDataUser;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lblDeskripsi;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.DateTimePicker dtpTanggalLahir;
        private System.Windows.Forms.Label lblNoTelp;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel pnlAdress;
        private System.Windows.Forms.Label lblAlamat;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblKelamin;
        private System.Windows.Forms.Label lblPosisi;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pbProfile;
        private System.Windows.Forms.Panel pnlSelectedUser;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnDeleteData;
        private System.Windows.Forms.Button btnUpdateData;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel pnlUpdateMain;
        private System.Windows.Forms.Panel pnlUpdateChild;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel pnlHintTelp;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblAlphabetCounterTelp;
        private System.Windows.Forms.Panel pnlHintId;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel pnlHintStatus;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox pbHintId;
        private System.Windows.Forms.PictureBox pbHintStatus;
        private System.Windows.Forms.PictureBox pbHintTelpNum;
        private System.Windows.Forms.Label lblAlphabetCounterAddr;
        private System.Windows.Forms.Label lblAlphabetCounterDesc;
        private System.Windows.Forms.DateTimePicker dtpDateofBirth;
        private System.Windows.Forms.Button btnVisiblePassCreate;
        private System.Windows.Forms.ComboBox cbGender;
        private System.Windows.Forms.ComboBox cbPosition;
        private System.Windows.Forms.Label dangerPosition;
        private System.Windows.Forms.Label dangerUsername;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtTelpNumber;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtIdKaryawan;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button btnSubmitUpdate;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Panel pnlDeleteDanger;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lblAlphabetCounterUsername;
    }
}